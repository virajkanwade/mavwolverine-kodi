# plugin.video.zeemarathi
Kodi video addon for http://www.zeemarathi.com

NOTE: Kodi has received an "Infringement Notice WRT copyright" (which makes no sense at all). Until we hear back from Zee/ Kodi, the addon will not be updated on the official repo. Updates will be published to this repo as and when I get time (till I receive such a notice)

INSTALL:
 * Visit https://github.com/virajkanwade/plugin.video.zeemarathi
 * Click on branch drop down
 * Select tags tab
 * Click on latest tag version
 * Click 'Download ZIP' button on the right
 * SSH to openelec
 * mkdir /storage/packages if does not exist
 * scp the downloaded zip to openelec inside the packages folder (You can delete older packages)
 * In Kodi, System > Settings > Add-ons
 * Click 'Install from zip file'
 * Open 'Home folder'
 * Open 'packages'
 * Open the zip file for the plugin

Latest version of the plugin should be installed
