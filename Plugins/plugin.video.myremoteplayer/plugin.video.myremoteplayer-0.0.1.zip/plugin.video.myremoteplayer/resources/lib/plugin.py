# -*- coding: utf-8 -*-

import routing
import logging
import xbmcaddon
from resources.lib import kodiutils
from resources.lib import kodilogging
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory

from base64 import urlsafe_b64encode, urlsafe_b64decode
import datetime
import json
import gzip
import os.path
import time
import urllib
from bs4 import BeautifulSoup
import urlresolver
# from xbmc import Player
from resources.lib import helpers as h


ADDON = xbmcaddon.Addon()
logger = logging.getLogger(ADDON.getAddonInfo('id'))
kodilogging.config()
plugin = routing.Plugin()

ROOT_URL = 'https://gist.githubusercontent.com/virajkanwade/35b43a34a3a9f7c0507ca591dc8ad3d6/raw/475770ecad81ab1db200e6a364e20755445aa158/myremoteplayer'
# https://gist.github.com/virajkanwade/35b43a34a3a9f7c0507ca591dc8ad3d6

addon_id = os.path.basename(os.path.dirname(os.path.abspath(__file__)))

@plugin.route('/')
def index():
    title = 'my video'
    with urllib.request.urlopen(ROOT_URL) as response:
        video_url = response.read()

    list_item = ListItem(title)
    list_item.setInfo('video', {'title': title})

    addDirectoryItem(plugin.handle, video_url, list_item)

    endOfDirectory(plugin.handle)


def run(argv):
    plugin.run(argv=argv)
