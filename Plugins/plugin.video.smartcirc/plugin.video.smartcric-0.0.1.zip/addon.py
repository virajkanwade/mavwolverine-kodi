from bs4 import BeautifulSoup
import os.path
import urlresolver
import urlparse
import xbmcplugin
import xmlrpclib
from lib import helpers as h
import sys


def main_index():
    name = 'ipl'
    video_url = 'https://42.smartcric.eu/mobile/stream2_320p/playlist.m3u8?id=7&pk=56ef5a93675b6148f1480ab436822888014b05b4027c41662cf06df6200a82b7'
    h.add_dir_video(addon_handle, name, video_url, '', '')


addon_id = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
cookie_file, cookie_jar = h.init_cookie_jar(addon_id)

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', ['', ])[0]

print('base_url', base_url)
print('addon_handle', addon_handle)
print('args', args)
print('mode', mode)

main_index()

xbmcplugin.endOfDirectory(addon_handle)
