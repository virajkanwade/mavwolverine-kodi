from bs4 import BeautifulSoup
import http.cookiejar
import os
import urllib
from datetime import datetime
import functools


ROOT_URL = 'https://www.desirulez.cc/'
USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36'

cookie_file = 'cookies.lwp'

cookie_jar = http.cookiejar.LWPCookieJar()
if os.path.exists(cookie_file):
    cookie_jar.load(cookie_file, ignore_discard=True)


def make_request(url, cookie_file, cookie_jar, headers={}):
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie_jar))
    request = urllib.request.Request(url)
    request.add_header('User-Agent', USER_AGENT)
    for key, val in headers.items():
        request.add_header(key, val)
    response = opener.open(request)
    data = response.read()
    cookie_jar.save(cookie_file, ignore_discard=True)

    # if data:
    #     data = data.decode('utf-8')

    return data

'''
i = 1501515
for x in range(400, 600):
    j = i - x
    print(j)
    data = make_request('https://www.desirulez.cc/showthread.php/' + str(j), cookie_file, cookie_jar)
    soup = BeautifulSoup(data, 'html.parser')
    print(soup.find('title'))
'''

links = []

def get_links(url):
    data = make_request(url, cookie_file, cookie_jar)
    soup = BeautifulSoup(data, 'html.parser')
    #import pdb
    #pdb.set_trace()
    ol = soup.find('ol', id='searchbits')
    if ol:
        #for li in soup.find('ol', class_='threads').find_all('li', class_='threadbit'):
        for li in ol.find_all('li', {'class': lambda x: x and 'threadbit' in x.split()}):
            a = li.find('div', class_='threadinfo').find('a', class_='title')
            if (a):
                # print(a)
                links.append(a)

    prev_next_spans = soup.find('div', id='pagination_top').find_all('span', class_='prev_next')
    for span in prev_next_spans:
        a = span.find('a')
        if a.attrs['rel'] == ['next']:
            get_links(ROOT_URL + a.attrs['href'])

get_links('https://www.desirulez.cc/search.php?searchid=12096817')

# print(links)

def get_link_date(url):
    parts = url.split('-Video-Watch-Online')[0].split('-')[-3:]
    parts[0] = parts[0][:-2]
    return datetime.strptime(' '.join(parts), '%d %B %Y').date()

def compare_links(x, y):
    td = get_link_date(y.attrs['href']) - get_link_date(x.attrs['href'])
    return td.days

sorted_links = sorted(links, key=functools.cmp_to_key(compare_links))

for a in sorted_links:
    print(f"{a.attrs['href']},{a.text}")
