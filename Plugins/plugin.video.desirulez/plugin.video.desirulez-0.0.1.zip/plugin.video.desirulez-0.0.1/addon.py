from BeautifulSoup import BeautifulSoup
import json
import os.path
import sys
import urlparse
import xbmcplugin
import xmlrpclib
from resources.lib import helpers as h


def main_index():
    forums = proxy.get_forum()
    for forum in forums:
        h.add_dir(addon_handle, base_url, forum['forum_name'].data, forum['forum_id'], 'forum', thumbnail=forum['logo_url'])


def forum():
    forum_id = h.extract_var(args, 'elem_id')
    forums = proxy.get_forum(False, forum_id)
    for forum in forums:
        h.add_dir(addon_handle, base_url, forum['forum_name'].data, forum['forum_id'], 'forum', thumbnail=forum['logo_url'])

    if not forums:
        topics = proxy.get_topic(forum_id, 0, 9, 'TOP')['topics']
        for topic in topics:
            h.add_dir(addon_handle, base_url, topic['topic_title'].data, topic['topic_id'], 'topic', thumbnail=topic['icon_url'])


def topic():
    topic_id = h.extract_var(args, 'elem_id')
    posts = proxy.get_thread(topic_id)['posts']
    post_content = posts[0]['post_content'].data

    content = post_content.split('\n\n')
    print content

    # videos = []

    try:
        idx = content.index('Flash Player 720p HD Quality Online Links')
    except ValueError:
        idx = -1

    if idx != -1:
        links_content = content[idx + 1].split('\n')
        for link_content in links_content:
            idx1 = link_content.find('[URL=')
            idx2 = link_content.find(']')
            url = link_content[idx1 + 5: idx2]

            soup = BeautifulSoup(h.make_request(url, cookie_file, cookie_jar))
            json_url = dict(soup.find('script', {'src': '//cdn.playwire.com/bolt/js/embed.min.js'}).attrs)['data-config']

            json_data = json.loads(h.make_request(json_url, cookie_file, cookie_jar))
            poster = json_data['poster']
            src = json_data['src']
            soup = BeautifulSoup(h.make_request(src, cookie_file, cookie_jar))
            base_url = soup.find('baseurl').text
            media_node = soup.find('media')
            media_url = dict(media_node.attrs)['url']
            video_url = '%s/%s' % (base_url, media_url)

            idx3 = link_content.find('[', idx2)

            name = link_content[idx2 + 1: idx3]

            # videos.append({'url': video_url, 'thumbnail': poster, 'name': name})
            h.add_dir_video(addon_handle, name, video_url, poster, '')

    # h.play_videos(addon_handle, videos)


API_URL = 'http://www.desirulez.me/mobiquo/mobiquo.php'
proxy = xmlrpclib.ServerProxy(API_URL)

addon_id = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
cookie_file, cookie_jar = h.init_cookie_jar(addon_id)

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', ['', ])[0]

if mode == 'forum':
    forum()
elif mode == 'topic':
    topic()
else:
    main_index()

xbmcplugin.endOfDirectory(addon_handle)
