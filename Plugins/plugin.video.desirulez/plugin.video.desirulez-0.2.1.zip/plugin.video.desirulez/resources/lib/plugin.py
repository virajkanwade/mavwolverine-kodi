# -*- coding: utf-8 -*-

import routing
import logging
import xbmcaddon
from resources.lib import kodiutils
from resources.lib import kodilogging
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory

import datetime
import json
import os.path
import time
import urllib

from bs4 import BeautifulSoup
import urlresolver
# from xbmc import Player
from resources.lib import helpers as h


ADDON = xbmcaddon.Addon()
logger = logging.getLogger(ADDON.getAddonInfo('id'))
kodilogging.config()
plugin = routing.Plugin()

ROOT_URL = 'https://www.desirulez.cc/'

addon_id = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
cookie_file, cookie_jar = h.init_cookie_jar(addon_id)


@plugin.route('/')
def index():
    fn = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'links.txt')
    try:
        url = 'https://drive.google.com/uc?export=download&id=1BldW-I4t4J95-EV-n3mc7JWEU4Ksv5a7'
        resp = h.make_request(url, cookie_file, cookie_jar).decode('utf-8')
        if resp:
            with open(fn, 'w') as f:
                f.write(resp)
    except:
        pass

    with open(fn) as f:
        lines = f.readlines()

    for line in lines:
        url, title = line.split(',', 1)
        _title = urllib.parse.quote_plus(title)
        _url = urllib.parse.quote_plus(url)
        addDirectoryItem(plugin.handle, plugin.url_for(show_serial, _title, _url), ListItem(title), True)

    endOfDirectory(plugin.handle)


@plugin.route('/serial/<name>/<url>')
def show_serial(name, url):
    url = urllib.parse.unquote_plus(url)

    print(url)

    resp = h.make_request(url, cookie_file, cookie_jar)
    soup = BeautifulSoup(resp, features="html.parser")

    for ol_class in ('stickies', 'threads'):
        ol = soup.find('ol', class_=ol_class)
        if ol:
            #for li in soup.find('ol', class_='threads').find_all('li', class_='threadbit'):
            for li in ol.find_all('li', {'class': lambda x: x and 'threadbit' in x.split()}):
                a = li.find('div', class_='threadinfo').find('a', class_='title')

                _title = urllib.parse.quote_plus(a.text)
                _url = urllib.parse.quote_plus('https://www.desirulez.cc/' + a.attrs['href'])
                addDirectoryItem(plugin.handle, plugin.url_for(show_episode, _title, _url), ListItem(a.text), True)

    endOfDirectory(plugin.handle)


@plugin.route('/episode/<name>/<url>')
def show_episode(name, url):
    name = urllib.parse.unquote_plus(name)
    url = urllib.parse.unquote_plus(url)

    resp = h.make_request(url, cookie_file, cookie_jar)
    soup = BeautifulSoup(resp, features="html.parser")

    div = soup.find('blockquote', class_='postcontent').find('div')

    div_html = div.decode_contents(formatter="html").replace('\n', '').replace('<br>', '')
    for child in BeautifulSoup(div_html, 'html.parser').children:
        if child.name not in ('br', 'img', None):
            if child.name == 'a':
                _title = urllib.parse.quote_plus(child.text)
                _url = urllib.parse.quote_plus(child.attrs['href'])
                addDirectoryItem(plugin.handle, plugin.url_for(show_episode_part, _title, _url), ListItem(child.text), True)
            else:
                addDirectoryItem(plugin.handle, '', ListItem(f'[COLOR yellow][B]{child.text}[/B][/COLOR]'))

    endOfDirectory(plugin.handle)


@plugin.route('/episode_part/<name>/<url>')
def show_episode_part(name, url):
    name = urllib.parse.unquote_plus(name)
    url = urllib.parse.unquote_plus(url)

    print('-=' * 50)
    print(name)
    print(url)

    resp = h.make_request(url, cookie_file, cookie_jar)
    soup = BeautifulSoup(resp, features="html.parser")

    for meta in soup.find_all('meta'):
        if 'http-equiv' in meta.attrs and meta.attrs['http-equiv'] == 'refresh':
            _url = meta.attrs['content'][len('0;URL='):]
            resp = h.make_request(_url, cookie_file, cookie_jar)
            soup = BeautifulSoup(resp, features="html.parser")

    _url = soup.find('iframe').attrs['src']
    print(_url)

    try:
        video_url = urlresolver.resolve(_url)
        if video_url:
            print(video_url)
            list_item = ListItem(name)
            list_item.setInfo('video', {'title': name})
            # , iconImage='DefaultVideo.png', thumbnailImage='')
            list_item.setArt({'thumb': '', 'icon': '', 'fanart': ''})

            addDirectoryItem(plugin.handle, video_url, list_item)
    except urlresolver.resolver.ResolverError:
        print('ResolverError', _url)

    endOfDirectory(plugin.handle)


def run(argv):
    plugin.run(argv=argv)
