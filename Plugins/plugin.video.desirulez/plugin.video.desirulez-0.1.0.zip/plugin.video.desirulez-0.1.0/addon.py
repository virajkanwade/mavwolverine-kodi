from bs4 import BeautifulSoup
import os.path
import urlresolver
import urlparse
import xbmcplugin
import xmlrpclib
from resources.lib import helpers as h


def main_index():
    fn = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'links.txt')
    try:
        url = 'https://drive.google.com/uc?export=download&id=1BldW-I4t4J95-EV-n3mc7JWEU4Ksv5a7'
        resp = h.make_request(url, cookie_file, cookie_jar)
        if resp:
            with open(fn, 'w') as f:
                f.write(resp)
    except:
        pass

    with open(fn) as f:
        lines = f.readlines()

    for line in lines:
        url, title = line.split(',', 1)
        h.add_dir(addon_handle, base_url, title, url, 'serial')


def serial():
    url = h.extract_var(args, 'elem_id')

    resp = h.make_request(url, cookie_file, cookie_jar)
    soup = BeautifulSoup(resp, features="html.parser")

    for ol_class in ('stickies', 'threads'):
        ol = soup.find('ol', class_=ol_class)
        if ol:
            #for li in soup.find('ol', class_='threads').find_all('li', class_='threadbit'):
            for li in ol.find_all('li', {'class': lambda x: x and 'threadbit' in x.split()}):
                a = li.find('div', class_='threadinfo').find('a', class_='title')

                h.add_dir(addon_handle, base_url, a.text, a.attrs['href'], 'episode')


def episode():
    url = h.extract_var(args, 'elem_id')

    resp = h.make_request(url, cookie_file, cookie_jar)
    soup = BeautifulSoup(resp, features="html.parser")

    div = soup.find('blockquote', class_='postcontent').find('div')

    div_html = div.decode_contents(formatter="html").replace('\n', '').replace('<br>', '')
    for child in BeautifulSoup(div_html, 'html.parser').children:
        if child.name not in ('br', 'img', None):
            if child.name == 'a':
                h.add_dir(addon_handle, base_url, child.text, child.attrs['href'], 'episode_part')
            else:
                h.add_dir(addon_handle, base_url, child.text, '', '', icon_image=None, thumbnail=None, is_folder=False)


def episode_part():
    url = h.extract_var(args, 'elem_id')
    name = h.extract_var(args, 'name')

    parsed_url = urlparse.urlparse(url)
    print(parsed_url)
    parsed_qs = urlparse.parse_qs(parsed_url.query)
    print(parsed_qs)
    if 'id' in parsed_qs:
        vid_id = parsed_qs['id'][0]

        if parsed_url.path == '/vkprime.php':
            url = 'http://vkprime.com/embed-%s.html' % vid_id
        elif parsed_url.path == '/speedwatch.php':
            url = 'http://vkspeed.com/embed-%s.html' % vid_id
        elif parsed_url.path == '/vidoza.php':
            url = 'http://vidoza.net/embed-%s.html' % vid_id
        elif parsed_url.path == '/watchvideo.php':
            url = 'http://watchvideo.us/embed-%s-540x304.html' % vid_id
        elif parsed_url.path == '/hqq.php':
            url = 'https://hqq.tv/player/embed_player.php?vid=%s&autoplay=no' % vid_id
        else:
            resp = h.make_request(url, cookie_file, cookie_jar)
            soup = BeautifulSoup(resp, features="html.parser")

            if len(soup.findChildren()) == 1:
                meta = soup.find('meta', attrs={'http-equiv': 'refresh'})
                if meta:
                    c = dict(meta.attrs)['content']
                    idx4 = c.find('URL=')
                    if idx4 != -1:
                        _url = c[idx4 + 4:]
                        soup = BeautifulSoup(h.make_request(_url, cookie_file, cookie_jar), features="html.parser")
                        url = soup.find('iframe', src=lambda src: src and vid_id in src).attrs['src']

        try:
            video_url = urlresolver.resolve(url)
            if video_url:
                h.add_dir_video(addon_handle, name, video_url, '', '')
        except urlresolver.resolver.ResolverError:
            print('ResolverError', url)

    elif parsed_url.netloc == 'bestarticles.me':
        path = None
        vid_id = None

        if parsed_url.path == '/ishqbaaz/':
            if 'sin' in parsed_qs:
                path = 'embed2'
                vid_id = parsed_qs['sin'][0]
            elif 'si' in parsed_qs:
                path = 'nflix2'
                vid_id = parsed_qs['si'][0]
        elif parsed_url.path == '/tere-sheher-mein/':
            path = 'plyr2'
            vid_id = parsed_qs['sid'][0]

        if path and vid_id:
            _url = 'https://flow.bestarticles.me/%s/%s/' % (path, vid_id)
            soup = BeautifulSoup(h.make_request(_url, cookie_file, cookie_jar), features="html.parser")
            for script_tag in soup.find_all('script'):
                print(script_tag)
                if 'var config = {' in script_tag.text:
                    txt = script_tag.text
                    idx = txt.index('"src":"')
                    txt = txt[idx + 7:]
                    idx = txt.index('"')
                    txt = txt[:idx]
                    if txt:
                        h.add_dir_video(addon_handle, name, txt, '', '')

addon_id = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
cookie_file, cookie_jar = h.init_cookie_jar(addon_id)

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', ['', ])[0]

print('base_url', base_url)
print('addon_handle', addon_handle)
print('args', args)
print('mode', mode)

if mode == 'serial':
    serial()
elif mode == 'episode':
    episode()
elif mode == 'episode_part':
    episode_part()
else:
    main_index()

xbmcplugin.endOfDirectory(addon_handle)
