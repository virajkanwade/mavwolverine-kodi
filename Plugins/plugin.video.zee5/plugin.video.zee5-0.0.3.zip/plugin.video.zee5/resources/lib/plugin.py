# -*- coding: utf-8 -*-

import routing
import logging
import xbmcaddon
from resources.lib import kodiutils
from resources.lib import kodilogging
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory

import datetime
import json
import os.path
import time
import urllib
from bs4 import BeautifulSoup
# from xbmc import Player
from resources.lib import helpers as h


ADDON = xbmcaddon.Addon()
logger = logging.getLogger(ADDON.getAddonInfo('id'))
kodilogging.config()
plugin = routing.Plugin()

TOKEN_URL = 'https://useraction.zee5.com/token/platform_tokens.php?platform_name=web_app'
ROOT_URL = 'https://www.zee5.com'
EPISODES_URL = 'https://gwapi.zee5.com/content/tvshow/%s?translation=en&country=CA&limit=10'
EPISODE_DETAILS_URL = 'https://gwapi.zee5.com/content/details/%s?translation=en&country=CA'
EPISODE_PLAYER_URL = 'https://gwapi.zee5.com/content/player/%s?user_type=guest&limit=25&translation=en&country=CA&languages=en,mr,te,ta,bn,pa'
VIDEO_TOKEN_URL = 'https://useraction.zee5.com/tokennd/'
AES_ROOT_URL = 'https://zee5vodnd.akamaized.net'

MARATHI_URL = 'https://www.zee5.com/global/collections/top-marathi-shows/0-8-1214'
LINKS_URL = 'https://drive.google.com/uc?export=download&id=1NitCYEUSLcxCHO_nX94-zqF7iuStqxc5'

addon_id = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
cookie_file, cookie_jar = h.init_cookie_jar(addon_id)


@plugin.route('/')
def index():
    resp = h.make_request(MARATHI_URL, cookie_file, cookie_jar)
    soup = BeautifulSoup(resp, 'html.parser')

    shows_divs = soup.find('div', class_='pageContentWrapper') \
                    .find('div', class_='viewAllMovie') \
                    .find('div', class_='viewAllWrap') \
                    .find_all('div', class_='viewAllGrid')

    for show_div in shows_divs:
        movie_card = show_div.find('div', class_='movieCard')

        _url = urllib.parse.quote_plus(EPISODES_URL % movie_card['data-contentid'])

        img = movie_card.find('div', class_='content').find('img')
        title = img['title']

        list_item = ListItem(title)
        list_item.setArt({'thumb': img['src']})

        addDirectoryItem(plugin.handle, plugin.url_for(show_serial, title, _url), list_item, True)

    endOfDirectory(plugin.handle)


@plugin.route('/home')
def home():
    fn = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'links.txt')
    try:
        resp = h.make_request(LINKS_URL, cookie_file, cookie_jar)
        if resp:
            with open(fn, 'w') as f:
                f.write(resp)
    except Exception as e:
        print(e)

    with open(fn) as f:
        lines = f.readlines()

    for line in lines:
        url, title = line.split(',', 1)
        _url = EPISODES_URL % url.split('/')[-2]
        _url = urllib.parse.quote_plus(_url)

        addDirectoryItem(plugin.handle, plugin.url_for(show_serial, title, _url), ListItem(title), True)

    endOfDirectory(plugin.handle)


@plugin.route('/serial/<name>/<url>')
def show_serial(name, url):
    def _process_episode(episode):
        #print(episode)
        dt = ''
        if 'release_date' in episode:
            format = '%Y-%m-%dT00:00:00'
            try:
                dt = datetime.datetime.strftime(datetime.datetime.strptime(episode['release_date'], format), '%Y %b %d')
            except TypeError:
                dt = datetime.datetime.strftime(datetime.datetime(*time.strptime(episode['release_date'], format)[:6]), '%Y %b %d')

        title = '%s - %s - %s' % (str(episode['episode_number']), dt, episode['title'])

        hls_url = AES_ROOT_URL + '/hls1' + episode['video_details']['hls_url'][5:]
        hls_url = urllib.parse.quote_plus(hls_url)

        ref_url = urllib.parse.quote_plus(ROOT_URL + '/' + episode['web_url'])

        img_url = urllib.parse.quote_plus(episode['image_url'])

        list_item = ListItem(title)
        list_item.setArt({'thumb': episode['image_url']})

        addDirectoryItem(plugin.handle, plugin.url_for(show_episode, title, hls_url, img_url, ref_url), list_item, True)

    url = urllib.parse.unquote_plus(url)
    print(url)

    resp = h.make_request(TOKEN_URL, cookie_file, cookie_jar)
    token = json.loads(resp)['token']

    headers = {
        'Origin': ROOT_URL,
        'Referer': ROOT_URL,
        'x-access-token': token,
    }

    print('%' * 100, url)
    resp = h.make_request(url, cookie_file, cookie_jar, headers)
    data = json.loads(resp)

    if 'season' not in data and 'episode' in data:
        for episode in data['episode']:
            _process_episode(episode)

        if 'next_episode_api' in data:
            _url = urllib.parse.quote_plus(data['next_episode_api'])
            addDirectoryItem(plugin.handle, plugin.url_for(show_serial, 'Next', _url), ListItem('Next'), True)
    else:
        for season in data['seasons']:
            for episode in season['episodes']:
                _process_episode(episode)

            if 'next_episodes_api' in season:
                _url = urllib.parse.quote_plus(season['next_episodes_api'])
                addDirectoryItem(plugin.handle, plugin.url_for(show_serial, 'Next', _url), ListItem('Next'), True)

    endOfDirectory(plugin.handle)


@plugin.route('/episode/<name>/<hls_url>/<img_url>/<ref_url>')
def show_episode(name, hls_url, img_url, ref_url):
    hls_url = urllib.parse.unquote_plus(hls_url)
    print(hls_url)

    img_url = urllib.parse.unquote_plus(img_url)

    headers = {
        'Referer': urllib.parse.unquote_plus(ref_url),
    }

    resp = h.make_request(VIDEO_TOKEN_URL, cookie_file, cookie_jar, headers)
    data = json.loads(resp)

    video_token = data['video_token']

    list_item = ListItem(name, label2='test label2')
    list_item.setInfo('video', {'title': name})
    # , iconImage='DefaultVideo.png', thumbnailImage='')
    list_item.setArt({'thumb': img_url, 'icon': img_url, 'fanart': ''})

    addDirectoryItem(plugin.handle, hls_url + video_token, list_item)
    # Player().play(hls_url + video_token, list_item)

    endOfDirectory(plugin.handle)


def run(argv):
    plugin.run(argv=argv)
