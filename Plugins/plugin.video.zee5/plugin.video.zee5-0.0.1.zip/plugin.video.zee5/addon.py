import datetime
import json
import os.path
import time
import urlparse
import xbmcplugin
import resources.lib.helpers as h

TOKEN_URL = 'https://useraction.zee5.com/token/platform_tokens.php?platform_name=web_app'
ROOT_URL = 'https://www.zee5.com'
EPISODES_URL = 'https://gwapi.zee5.com/content/tvshow/%s?translation=en&country=CA'
EPISODE_DETAILS_URL = 'https://gwapi.zee5.com/content/details/%s?translation=en&country=CA'
EPISODE_PLAYER_URL = 'https://gwapi.zee5.com/content/player/%s?user_type=guest&limit=25&translation=en&country=CA&languages=en,mr,te,ta,bn,pa'
VIDEO_TOKEN_URL = 'https://useraction.zee5.com/tokennd/'
AES_ROOT_URL = 'https://zee5vodnd.akamaized.net'


def main_index():
    fn = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'links.txt')
    try:
        url = 'https://drive.google.com/uc?export=download&id=1NitCYEUSLcxCHO_nX94-zqF7iuStqxc5'
        resp = h.make_request(url, cookie_file, cookie_jar)
        if resp:
            with open(fn, 'w') as f:
                f.write(resp)
    except:
        pass

    with open(fn) as f:
        lines = f.readlines()

    for line in lines:
        url, title = line.split(',', 1)
        h.add_dir(addon_handle, base_url, title, url, 'serial')


def serial():
    url = h.extract_var(args, 'elem_id')
    name = h.extract_var(args, 'name')

    resp = h.make_request(TOKEN_URL, cookie_file, cookie_jar)
    token = json.loads(resp)['token']

    headers = {
        'Origin': ROOT_URL,
        'Referer': ROOT_URL,
        'x-access-token': token,
    }

    _url = EPISODES_URL % url.split('/')[-2]

    resp = h.make_request(_url, cookie_file, cookie_jar, headers)
    data = json.loads(resp)

    for season in data['seasons']:
        for episode in season['episodes']:
            print(episode)
            dt = ''
            format = '%Y-%m-%dT00:00:00'
            try:
                dt = datetime.datetime.strftime(datetime.datetime.strptime(episode['release_date'], format), '%Y %b %d')
            except TypeError:
                dt = datetime.datetime.strftime(datetime.datetime(*time.strptime(episode['release_date'], format)[:6]), '%Y %b %d')
            title = '%s - %s - %s' % (str(episode['episode_number']), dt, episode['title'])
            hls_url = AES_ROOT_URL + '/hls1' + episode['video_details']['hls_url'][5:]
            _url1 = ROOT_URL + '/' + episode['web_url'] + ';' + hls_url
            h.add_dir(addon_handle, base_url, title, _url1, 'episode', thumbnail=episode['image_url'])


def episode():
    url = h.extract_var(args, 'elem_id')
    name = h.extract_var(args, 'name')

    ref_url, hls_url = url.split(';')

    headers = {
        'Referer': ref_url,
    }

    resp = h.make_request(VIDEO_TOKEN_URL, cookie_file, cookie_jar, headers)
    data = json.loads(resp)

    video_token = data['video_token']

    h.add_dir_video(addon_handle, name, hls_url + video_token, '', '')


addon_id = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
cookie_file, cookie_jar = h.init_cookie_jar(addon_id)

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', ['', ])[0]

print('base_url', base_url)
print('addon_handle', addon_handle)
print('args', args)
print('mode', mode)

if mode == 'serial':
    serial()
elif mode == 'episode':
    episode()
else:
    main_index()

xbmcplugin.endOfDirectory(addon_handle)