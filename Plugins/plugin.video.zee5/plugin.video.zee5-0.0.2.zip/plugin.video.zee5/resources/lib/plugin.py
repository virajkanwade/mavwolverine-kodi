# -*- coding: utf-8 -*-

import routing
import logging
import xbmcaddon
from resources.lib import kodiutils
from resources.lib import kodilogging
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory

import datetime
import json
import os.path
import time
import urllib
from resources.lib import helpers as h


ADDON = xbmcaddon.Addon()
logger = logging.getLogger(ADDON.getAddonInfo('id'))
kodilogging.config()
plugin = routing.Plugin()

TOKEN_URL = 'https://useraction.zee5.com/token/platform_tokens.php?platform_name=web_app'
ROOT_URL = 'https://www.zee5.com'
EPISODES_URL = 'https://gwapi.zee5.com/content/tvshow/%s?translation=en&country=CA&limit=10'
EPISODE_DETAILS_URL = 'https://gwapi.zee5.com/content/details/%s?translation=en&country=CA'
EPISODE_PLAYER_URL = 'https://gwapi.zee5.com/content/player/%s?user_type=guest&limit=25&translation=en&country=CA&languages=en,mr,te,ta,bn,pa'
VIDEO_TOKEN_URL = 'https://useraction.zee5.com/tokennd/'
AES_ROOT_URL = 'https://zee5vodnd.akamaized.net'

LINKS_URL = 'https://drive.google.com/uc?export=download&id=1NitCYEUSLcxCHO_nX94-zqF7iuStqxc5'
addon_id = os.path.basename(os.path.dirname(os.path.abspath(__file__)))
cookie_file, cookie_jar = h.init_cookie_jar(addon_id)


@plugin.route('/')
def index():
    fn = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'links.txt')
    try:
        resp = h.make_request(LINKS_URL, cookie_file, cookie_jar)
        if resp:
            with open(fn, 'w') as f:
                f.write(resp)
    except Exception as e:
        print(e)

    with open(fn) as f:
        lines = f.readlines()

    for line in lines:
        url, title = line.split(',', 1)
        _url = EPISODES_URL % url.split('/')[-2]
        _url = urllib.parse.quote_plus(_url)

        addDirectoryItem(plugin.handle, plugin.url_for(show_serial, title, _url), ListItem(title), True)

    endOfDirectory(plugin.handle)


@plugin.route('/serial/<name>/<url>')
def show_serial(name, url):
    def _process_episode(episode):
        print(episode)
        dt = ''
        if 'release_date' in episode:
            format = '%Y-%m-%dT00:00:00'
            try:
                dt = datetime.datetime.strftime(datetime.datetime.strptime(episode['release_date'], format), '%Y %b %d')
            except TypeError:
                dt = datetime.datetime.strftime(datetime.datetime(*time.strptime(episode['release_date'], format)[:6]), '%Y %b %d')
        title = '%s - %s - %s' % (str(episode['episode_number']), dt, episode['title'])
        hls_url = AES_ROOT_URL + '/hls1' + episode['video_details']['hls_url'][5:]
        _url1 = ROOT_URL + '/' + episode['web_url'] + ';' + hls_url
        _url1 = urllib.parse.quote_plus(_url1)
        addDirectoryItem(plugin.handle, plugin.url_for(show_episode, title, _url1), ListItem(title), True)

    url = urllib.parse.unquote_plus(url)
    print(url)

    resp = h.make_request(TOKEN_URL, cookie_file, cookie_jar)
    token = json.loads(resp)['token']

    headers = {
        'Origin': ROOT_URL,
        'Referer': ROOT_URL,
        'x-access-token': token,
    }

    print('%'* 100, url)
    resp = h.make_request(url, cookie_file, cookie_jar, headers)
    data = json.loads(resp)

    if 'season' not in data and 'episode' in data:
        for episode in data['episode']:
            _process_episode(episode)

        if 'next_episode_api' in data:
            _url = urllib.parse.quote_plus(data['next_episode_api'])
            addDirectoryItem(plugin.handle, plugin.url_for(show_serial, 'Next', _url), ListItem('Next'), True)
    else:
        for season in data['seasons']:
            for episode in season['episodes']:
                _process_episode(episode)

            if 'next_episodes_api' in season:
                _url = urllib.parse.quote_plus(season['next_episodes_api'])
                addDirectoryItem(plugin.handle, plugin.url_for(show_serial, 'Next', _url), ListItem('Next'), True)

    endOfDirectory(plugin.handle)


@plugin.route('/episode/<name>/<url>')
def show_episode(name, url):
    url = urllib.parse.unquote_plus(url)
    print(url)

    ref_url, hls_url = url.split(';')

    headers = {
        'Referer': ref_url,
    }

    resp = h.make_request(VIDEO_TOKEN_URL, cookie_file, cookie_jar, headers)
    data = json.loads(resp)

    video_token = data['video_token']

    list_item = ListItem(name)
    list_item.setInfo('video', {'title': name})
    list_item.setArt({'thumb': '', 'icon': 'DefaultVideo.png', 'fanart': ''})
    addDirectoryItem(plugin.handle, hls_url + video_token, list_item)

    endOfDirectory(plugin.handle)


def run(argv):
    plugin.run(argv=argv)
